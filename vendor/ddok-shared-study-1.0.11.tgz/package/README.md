# 두 앱 연동 구현과 확인 방법

현재 소스는 두 앱의 계정·프로필·목표·공부 세션·통계·시험·친구·승인형 비공개방·일지·동의 기반 AI 분석을 연결합니다. 운영 Firebase/Render/Play Console에는 배포하지 않았습니다.

## 프로젝트와 조사 결과

- 똑: ../ddok-app (React 19.2.7, TypeScript 5.8.3, Vite 6.4.5, Capacitor core 8.5.3, Firebase 12.19.0 설치 상태)
- 똑 타이머: ../ddok-timer (React 19.3.1, TypeScript 7.0.2, Vite 8.3.6, Capacitor core 8.6.0, Firebase 12.15.0)
- 두 앱은 gen-lang-client-0685740024 프로젝트와 기존 named Firestore ai-studio-22fbd27c-5516-4028-bd17-a6d4ba99710b를 사용합니다. 서로 다른 앱의 로그인 세션을 임의로 복사하지 않습니다.
- 기존 똑은 이메일·Google·Apple 코드가 있고, 타이머는 같은 계정의 이메일 인증/웹 Google 및 설치된 똑 승인 연결을 제공합니다. Native Google/Apple 직접 로그인은 별도 타이머 Firebase 앱 등록과 네이티브 설정 없이 활성화하지 않았습니다.
- 기존 목표 goal은 자유 텍스트, 시험 schedules는 날짜 문자열입니다. 자동으로 숫자 목표나 시각을 추측하지 않습니다. MIGRATION.md 및 src/migration.ts의 확인형 가져오기를 사용합니다.

## 위치와 사용

똑 홈의 '오늘의 연동 학습' → 목표·통계·시험·친구 공부방. 타이머 첫 화면도 같은 공유 요약을 표시합니다. 타이머 완료 시 개인 일지는 선택이며, 일지를 쓰지 않아도 세션은 계정별 큐에 남습니다. 기기 통계와 공유 통계는 구분해서 볼 수 있습니다. 공유 기록은 로그인 후 재설치 기기에서도 Firestore 실시간 구독으로 복원합니다.

공유 라이브러리는 @ddok/shared-study이며 두 앱 vendor에 동일 tarball을 포함합니다. GitHub CI에서 부모 디렉터리가 없어도 npm ci가 동작하도록 로컬 vendor 파일에 의존합니다. 변경 시 이 폴더에서 npm run build, npm pack을 실행하고 두 앱 vendor/와 package-lock.json을 함께 갱신합니다.

## 기능과 개인정보

- 같은 Firebase UID로 로그인하고 프로필 이름·학교·사진·타이머 알림 설정을 공유합니다. 로그아웃/계정 전환 시 구독을 해제하며 큐와 기기 기록은 UID로 격리합니다.
- 목표 완료량은 서버의 검증된 세션만 집계합니다. 세션 ID 중복은 1회만 집계하고, 휴식은 실제 구간에서 제외합니다. 클라이언트 시간이 조작되지 않았음을 하드웨어로 보증하는 시스템은 아니며, 서버가 범위·합계·중복·겹침을 검증하는 연습용 공부 기록입니다.
- 앱 강제 종료 후 타이머는 시작/종료 절대 시각으로 복구합니다. 종료 후 확정한 공부 구간을 서버에 보냅니다. 네트워크 실패는 재전송하고 영구 거절 기록은 버리지 않고 계정 화면의 확인 목록에 보관합니다. 잘못된 한 기록이 다음 기록을 막지 않습니다.
- 기본 방은 비공개이며 초대 후 방장 승인이 필요합니다. 기존 공개/학교방 및 경쟁 랭킹 코드는 기본 노출을 끄고 보존했습니다. VITE_ENABLE_LEGACY_ROOMS/DDOK_ENABLE_LEGACY_ROOMS와 VITE_ENABLE_RANKING은 기본 비활성입니다. 새 친구는 양방향 승인으로 관리하며 비공개방 접속만으로 자동 친구로 등록하지 않습니다.
- 초대 원문은 해시로 저장하고 만료를 검사합니다. 권한/차단/승인/정원은 서버가 검증합니다. 존재 상태는 90초 기한, 30초 갱신이며 외부 채팅이나 개인 일정 공유는 기본 제공하지 않습니다.
- 공동 시계는 방장이 제어합니다. 개인 공부량은 개인 타이머로 별도 완료한 구간만 집계해 공동 시계를 허위 개인 공부량으로 자동 복사하지 않습니다.
- AI는 Cloud Functions ddokStudyInsights만 호출합니다. 기존 똑의 다른 AI API는 그대로 유지합니다. 새 AI 분석에는 이름·학교·일지 원문·세부 시각을 보내지 않고 최근 세션 합계만 보냅니다. 사용자가 기능을 켜고 매 요청 전 동의해야 하며 기본은 꺼짐입니다. 기록이 3회 미만이면 분석하지 않습니다. API 실패 시 기본 통계는 계속 작동하고 개인 AI 횟수는 환불합니다.
- 새 AI도 기존 무료 월30회/PRO 월100회 카운터를 KST 기준으로 공유합니다. 하루 전역 요청 상한, 출력 토큰 상한, 캐시와 요청 빈도 제한을 둡니다. 실제 API 청구액은 보증하지 않으며 설정된 단가와 제공된 usageMetadata로만 예상 비용을 기록합니다.
- 사진·학교 이름은 프로필에 입력한 정보이며 실제 재학 여부를 증명하지 않습니다.
- 계정 삭제 버튼은 두 앱의 공통 계정에 적용됩니다. 기존 똑 삭제 API가 개인 문서/계정을 지우고 Auth 삭제 이벤트가 공유방·친구·초대·집계를 정리합니다. 삭제 요청 시작 UID를 고정하고 도중 계정 변경 시 새 계정의 저장소/세션은 건드리지 않습니다. 구독 해지는 스토어에서 별도 처리해야 합니다.

## 운영 반영 전 필요한 설정

1. 변경 내용을 검토하고 Firebase 프로젝트/데이터베이스가 위 값과 맞는지 확인합니다. Functions 배포에는 Firebase Blaze 결제 연결과 필요한 IAM이 필요합니다. 여기서 결제 연결이나 유료 리소스 생성을 수행하지 않았습니다.
2. Node22와 Java21을 준비합니다. `npm ci`, `npm --prefix functions ci`, `npm --prefix security ci` 후 각 빌드/테스트를 실행합니다. 기존 Firebase 운영 데이터는 테스트에 사용하지 않습니다.
3. firestore.rules는 ../ddok-app/firestore.rules의 복사본입니다. 배포 전에 다시 복사하고 해시를 비교합니다. firestore.indexes.json도 함께 검토합니다. Emulator 검증 후 명시적으로 `firebase deploy --project gen-lang-client-0685740024 --only firestore,functions:ddok-shared`를 수행합니다. 기본 프로젝트는 demo-ddok-shared로 설정해 실수 배포를 방지합니다.
4. AI를 사용할 때만 Secret Manager에 GEMINI_API_KEY를 등록하고 DDOK_STUDY_INSIGHTS_ENABLED=true를 설정합니다. 모델 기본값은 gemini-2.5-flash-lite입니다. 전역 일일 상한/토큰 단가는 functions/README.md를 확인합니다. 실제 키는 채팅·클라이언트 소스·.env 예시에 넣지 마세요.
5. 인증 승인 도메인에 실제 웹 주소를 등록합니다. 로컬 웹 Google 로그인은 localhost/127.0.0.1 승인도 필요할 수 있습니다. 기존 똑 승인 연결은 수정된 똑 APK와 서버의 /api/timer-auth/issue 및 /timer-auth/exchange가 함께 필요합니다. 코드만 연결했고 운영 서버에는 배포하지 않았습니다.
6. 실제 타이머 공개 HTTPS 주소를 VITE_TIMER_PUBLIC_URL로 두 앱 빌드에 넣습니다. 공개 주소가 없으면 비공개방 초대는 코드와 코드 QR만 제공하며, 로컬 capacitor 주소를 외부 링크처럼 복사하지 않습니다. 웹 계정 승인 연결의 똑 쪽에는 VITE_TIMER_WEB_URL을 같은 공개 주소로 설정합니다.
7. Android App Links / iOS Universal Links는 소유한 도메인의 assetlinks.json/AASA와 실제 서명/팀 ID로 별도 검증해야 합니다. 현재 커스텀 scheme 흐름은 구현했으나 실제 기기 검증과 도메인 소유 검증을 완료하지 않았습니다.
8. App Check는 강제 적용 전 Android Play Integrity/웹 reCAPTCHA 설정과 실제 설치 채널을 검토해야 합니다. 인증·소유자·권한 검사와 별도로 App Check 강제 적용은 아직 설정하지 않았습니다.

## 테스트와 에뮬레이터

- 공통 SDK: npm test — 계정 전환, 오프라인/재전송, 영구 거절 기록 보존, 삭제 계정 고정, 마이그레이션 확인 테스트.
- 규칙/트랜잭션: security 폴더 npm test — loopback Firestore Emulator만 사용합니다. 최신 결과는 security/test-results.log.
- Functions: functions/VERIFICATION.md의 Node22·Auth/Firestore/Functions Emulator 실행법. 가짜 제공자 테스트로 AI 동의·캐시·실패 환불·출력 검증을 확인하며, 실제 Gemini 호출은 하지 않았습니다.
- 전체 로컬 개발: 각 앱 `.env.local`에 VITE_USE_FIREBASE_EMULATORS=true를 넣고 이 폴더의 firebase.json으로 `firebase emulators:start --project demo-ddok-shared`를 실행합니다. **현재 앱 클라이언트의 프로젝트 ID도 demo-ddok-shared로 에뮬레이터 모드에서만 바꿉니다.** 운영 빌드에서는 에뮬레이터 옵션을 사용하지 않습니다.
- 시험 하루 전 알림은 명시적 버튼/권한 승인 후 Android/iOS 로컬 알림에 예약합니다. 다른 기기에서 시험을 바꾼 경우 해당 기기 앱을 열었을 때 예약을 갱신합니다. 실제 기기의 전달/백그라운드 조건은 아직 검증하지 않았습니다.

## 검증하지 못한 범위

운영 Firebase/Render 배포, 실제 두 휴대폰 간 인증 왕복, 프로덕션 IAM·시크릿, 실제 Gemini, Android/iOS 알림 전달, App Links/AASA, 실제 iOS 빌드와 기기 회전은 별도 검증이 필요합니다. UI 자동 확인 도구가 실행되지 않아 브라우저의 최종 렌더링을 스크린샷으로 검증하지 못했습니다. 웹 타입 검사·번들 빌드와 에뮬레이터 결과를 기기 테스트 완료로 표시하지 않습니다.

클라이언트 npm audit는 고위험 발견 없음이며, Firebase 서버 간접 의존성의 중간 위험 경고는 functions/VERIFICATION.md에 남겨 두었습니다. 보안 취약점이 전혀 없다는 보증은 하지 않습니다.
